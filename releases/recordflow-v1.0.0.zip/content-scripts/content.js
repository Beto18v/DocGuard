var content=(function(){function e(e){return e}var t=`recordings`;function n(){return new Promise((e,n)=>{let r=indexedDB.open(`RecordFlowDB`,1);r.onupgradeneeded=e=>{let n=e.target.result;n.objectStoreNames.contains(t)||n.createObjectStore(t,{keyPath:`id`}).createIndex(`timestamp`,`timestamp`,{unique:!1})},r.onsuccess=()=>e(r.result),r.onerror=()=>n(r.error)})}async function r(e){let r=await n();return new Promise((n,i)=>{let a=r.transaction(t,`readwrite`).objectStore(t).put(e);a.onsuccess=()=>n(),a.onerror=()=>i(a.error)})}var i={es:{app_name:`RecordFlow`,app_tagline:`Grabador local e ilimitado de pantalla y cámara`,unlimited_badge:`100% Local • Ilimitado`,loom_alt:`Alternativa Libre a Loom`,status_ready:`Listo`,status_recording:`Grabando`,tab_record:`Grabador`,tab_recent:`Grabaciones Recientes`,mode_screen_camera:`Pantalla + Cámara`,mode_screen_only:`Solo Pantalla`,mode_camera_only:`Solo Cámara`,mode_screen_camera_desc:`Graba la pantalla con tu cámara en burbuja circular flotante`,mode_screen_only_desc:`Graba toda la pantalla, ventana o pestaña seleccionada`,mode_camera_only_desc:`Graba exclusivamente tu cámara web`,audio_mic_label:`Micrófono`,audio_mic_active:`Activo`,audio_mic_muted:`Silenciado`,audio_mic_desc:`Incluir voz desde el micrófono en la grabación`,btn_start_recording:`Iniciar Grabación`,btn_stop_recording:`Detener Grabación`,btn_finish_recording:`Finalizar`,btn_cancel:`Cancelar`,btn_download_video:`Descargar Video (.webm)`,btn_copy_link:`Copiar Enlace Local`,btn_link_copied:`¡Enlace copiado!`,btn_record_new:`Grabar Nuevo Video`,btn_delete:`Eliminar`,btn_rename:`Renombrar`,btn_save:`Guardar`,floating_recording:`REC`,floating_finish:`Finalizar`,no_recordings_title:`No hay grabaciones guardadas`,no_recordings_desc:`Tus videos se guardan 100% en tu navegador, sin límites ni nubes de terceros.`,meta_duration:`Duración`,meta_size:`Tamaño`,meta_date:`Fecha`,meta_mode:`Modo`,confirm_delete:`¿Estás seguro de que deseas eliminar esta grabación? Esta acción no se puede deshacer.`,preview_header_title:`RecordFlow Studio`,preview_subtitle:`Grabación completada con éxito • Almacenamiento local`,preview_player_title:`Reproductor de Video`,preview_file_details:`Detalles del Archivo`,preview_all_recordings:`Tus Grabaciones Guardadas`,preview_format:`Formato WebM de alta fidelidad`,err_restricted_page:`Por favor abre una página web regular (HTTP/HTTPS) para grabar.`,err_permission_denied:`Permiso de pantalla o cámara denegado.`,err_recording_failed:`Ocurrió un error al iniciar la grabación.`,notice_recording_active:`Grabación en curso en la pestaña activa...`,universal_studio_title:`RecordFlow Studio — Grabador Universal`,universal_studio_subtitle:`Graba cualquier pantalla, ventana o aplicación del equipo`,universal_status_recording:`🔴 Grabando pantalla...`,universal_instructions:`Puedes minimizar esta pestaña y trabajar en cualquier aplicación de tu equipo (VS Code, terminal, juegos, etc.). Cuando termines, haz clic en Detener o usa el botón 'Dejar de compartir' de Chrome.`,universal_btn_stop_save:`⏹️ Detener y Guardar Grabación`,universal_prompt_title:`Estudio de Grabación Universal`,universal_prompt_desc:`Graba cualquier aplicación, ventana o tu pantalla completa sin restricciones.`,universal_btn_start_share:`🚀 Seleccionar Pantalla y Comenzar`,universal_cancelled_title:`Selección Cancelada`,universal_cancelled_desc:`No se seleccionó ninguna pantalla o se canceló el permiso. Puedes reintentar cuando desees.`,universal_btn_retry:`🔄 Reintentar Selección`,open_universal_studio:`O abrir Estudio Universal para grabar cualquier app`,developed_by:`Desarrollado por`},en:{app_name:`RecordFlow`,app_tagline:`Local-first & unlimited screen and camera recorder`,unlimited_badge:`100% Local • Unlimited`,loom_alt:`Free Loom Alternative`,status_ready:`Ready`,status_recording:`Recording`,tab_record:`Recorder`,tab_recent:`Recent Recordings`,mode_screen_camera:`Screen + Camera`,mode_screen_only:`Screen Only`,mode_camera_only:`Camera Only`,mode_screen_camera_desc:`Record screen with circular floating webcam bubble`,mode_screen_only_desc:`Record full screen, window, or selected tab`,mode_camera_only_desc:`Record webcam video exclusively`,audio_mic_label:`Microphone`,audio_mic_active:`Active`,audio_mic_muted:`Muted`,audio_mic_desc:`Include voice from microphone in recording`,btn_start_recording:`Start Recording`,btn_stop_recording:`Stop Recording`,btn_finish_recording:`Finish`,btn_cancel:`Cancel`,btn_download_video:`Download Video (.webm)`,btn_copy_link:`Copy Local Link`,btn_link_copied:`Link copied!`,btn_record_new:`Record New Video`,btn_delete:`Delete`,btn_rename:`Rename`,btn_save:`Save`,floating_recording:`REC`,floating_finish:`Finish`,no_recordings_title:`No saved recordings yet`,no_recordings_desc:`Your videos are saved 100% locally in your browser with zero caps.`,meta_duration:`Duration`,meta_size:`Size`,meta_date:`Date`,meta_mode:`Mode`,confirm_delete:`Are you sure you want to delete this recording? This action cannot be undone.`,preview_header_title:`RecordFlow Studio`,preview_subtitle:`Recording finished successfully • Local storage`,preview_player_title:`Video Player`,preview_file_details:`File Details`,preview_all_recordings:`Your Saved Recordings`,preview_format:`High-fidelity WebM container`,err_restricted_page:`Please navigate to a regular web page (HTTP/HTTPS) to record.`,err_permission_denied:`Screen or camera permission was denied.`,err_recording_failed:`An error occurred while starting the recording.`,notice_recording_active:`Recording in progress on active tab...`,universal_studio_title:`RecordFlow Studio — Universal Recorder`,universal_studio_subtitle:`Record any screen, window, or desktop application`,universal_status_recording:`🔴 Recording screen...`,universal_instructions:`You can minimize this tab and work in any application on your computer (VS Code, terminal, games, etc.). When you're done, click Stop or use Chrome's 'Stop sharing' button.`,universal_btn_stop_save:`⏹️ Stop and Save Recording`,universal_prompt_title:`Universal Studio Recorder`,universal_prompt_desc:`Record any application, window, or your entire screen without page restrictions.`,universal_btn_start_share:`🚀 Select Screen & Start`,universal_cancelled_title:`Selection Cancelled`,universal_cancelled_desc:`No screen was selected or permission was cancelled. You can retry whenever you are ready.`,universal_btn_retry:`🔄 Retry Selection`,open_universal_studio:`Or open Universal Studio to record any app`,developed_by:`Developed by`}},a=`recordflow_lang`;async function o(){try{let e=await chrome.storage.local.get(a);if(e[a]===`es`||e[a]===`en`)return e[a]}catch{}return navigator.language.toLowerCase().startsWith(`es`)?`es`:`en`}function s(e,t=`es`){return i[t]?.[e]||i.en[e]||e}function c(e){let t=Math.floor(e/60),n=Math.floor(e%60);return`${t.toString().padStart(2,`0`)}:${n.toString().padStart(2,`0`)}`}function l(e,t=`es`){return new Date(e).toLocaleString(t===`es`?`es-ES`:`en-US`,{month:`short`,day:`numeric`,hour:`2-digit`,minute:`2-digit`})}var u=e({matches:[`<all_urls>`],runAt:`document_idle`,main(){let e=null,t=[],n=null,i=null,a=null,u=0,d=0,f=!1,p=null,m=null,h=null,g=null,_=null;function v(){for(let e of[`video/webm;codecs=vp9,opus`,`video/webm;codecs=vp8,opus`,`video/webm;codecs=h264,opus`,`video/webm`])if(typeof MediaRecorder<`u`&&MediaRecorder.isTypeSupported(e))return e;return`video/webm`}function y(){let e=[p,m,h,g];for(let t of e)t&&t.getTracks().forEach(e=>{try{e.stop(),e.enabled=!1}catch{}});if(p=null,m=null,h=null,g=null,_&&_.state!==`closed`){try{_.close()}catch{}_=null}}function b(){a&&=(clearInterval(a),null),n&&n.parentNode&&n.parentNode.removeChild(n),n=null,i=null}async function x(t){f||(f=!0,a&&=(clearInterval(a),null),d=Math.max(1,Math.round((Date.now()-u)/1e3)),e&&e.state!==`inactive`?e.stop():await S(t))}async function S(n){y(),b();let i=v(),a=new Blob(t,{type:i}),c=`rf_${Date.now()}_${Math.random().toString(36).substring(2,7)}`,u=await o(),p=`${s(`app_name`,u)} — ${l(Date.now(),u)}`;try{await r({id:c,title:p,timestamp:Date.now(),duration:d,size:a.size,mode:n,mimeType:i,blob:a}),chrome.runtime.sendMessage({type:`RECORDING_FINISHED`,id:c})}catch(e){console.error(`[RecordFlow] Failed to save recording to IndexedDB:`,e)}finally{t=[],e=null,f=!1}}function C(e,t,r){b(),n=document.createElement(`div`),n.id=`recordflow-overlay-root`,n.style.position=`fixed`,n.style.zIndex=`2147483647`,n.style.pointerEvents=`none`,n.style.top=`0`,n.style.left=`0`,n.style.width=`100vw`,n.style.height=`100vh`,i=n.attachShadow({mode:`open`});let o=document.createElement(`style`);o.textContent=`
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
          user-select: none;
        }

        .bubble-wrapper {
          position: fixed;
          bottom: 32px;
          left: 32px;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 12px;
          pointer-events: auto;
          cursor: grab;
          transition: transform 0.15s cubic-bezier(0.16, 1, 0.3, 1);
        }

        .bubble-wrapper:active {
          cursor: grabbing;
        }

        /* Circular Webcam Bubble */
        .camera-bubble {
          width: 156px;
          height: 156px;
          border-radius: 50%;
          overflow: hidden;
          background: #0f172a;
          border: 3.5px solid #6366f1;
          box-shadow: 
            0 0 25px rgba(99, 102, 241, 0.55),
            0 10px 30px rgba(0, 0, 0, 0.45);
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
          transform: translateZ(0);
        }

        .camera-video {
          width: 100%;
          height: 100%;
          object-fit: cover;
          transform: scaleX(-1); /* Mirror camera for natural feel */
        }

        /* Floating Control Bar */
        .control-bar {
          background: rgba(15, 23, 42, 0.88);
          backdrop-filter: blur(16px);
          -webkit-backdrop-filter: blur(16px);
          border: 1px solid rgba(255, 255, 255, 0.18);
          border-radius: 9999px;
          padding: 6px 14px 6px 12px;
          display: flex;
          align-items: center;
          gap: 10px;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.45);
          color: #ffffff;
        }

        .rec-indicator {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.05em;
          color: #f87171;
        }

        .rec-dot {
          width: 8px;
          height: 8px;
          background-color: #ef4444;
          border-radius: 50%;
          animation: pulse-dot 1.2s infinite ease-in-out;
        }

        @keyframes pulse-dot {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.35; transform: scale(0.85); }
        }

        .timer-display {
          font-size: 13px;
          font-weight: 600;
          font-variant-numeric: tabular-nums;
          color: #f1f5f9;
        }

        .btn-finish {
          display: flex;
          align-items: center;
          gap: 6px;
          background: #ef4444;
          color: #ffffff;
          border: none;
          border-radius: 9999px;
          padding: 5px 12px;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
          transition: background 0.15s, transform 0.1s;
        }

        .btn-finish:hover {
          background: #dc2626;
          transform: scale(1.03);
        }

        .btn-finish:active {
          transform: scale(0.97);
        }

        .square-icon {
          width: 8px;
          height: 8px;
          background: #ffffff;
          border-radius: 2px;
        }
      `,i.appendChild(o);let l=document.createElement(`div`);if(l.className=`bubble-wrapper`,e){let t=document.createElement(`div`);t.className=`camera-bubble`;let n=document.createElement(`video`);n.className=`camera-video`,n.autoplay=!0,n.playsInline=!0,n.muted=!0,n.srcObject=e,t.appendChild(n),l.appendChild(t)}let d=document.createElement(`div`);d.className=`control-bar`;let f=document.createElement(`div`);f.className=`rec-indicator`;let p=document.createElement(`span`);p.className=`rec-dot`;let m=document.createElement(`span`);m.textContent=s(`floating_recording`,r),f.appendChild(p),f.appendChild(m);let h=document.createElement(`span`);h.className=`timer-display`,h.textContent=`00:00`;let g=document.createElement(`button`);g.className=`btn-finish`;let _=document.createElement(`span`);_.className=`square-icon`;let v=document.createElement(`span`);v.textContent=s(`floating_finish`,r),g.appendChild(_),g.appendChild(v),g.addEventListener(`click`,e=>{e.stopPropagation(),x(t)}),d.appendChild(f),d.appendChild(h),d.appendChild(g),l.appendChild(d);let y=!1,S=0,C=0,w=32,T=window.innerHeight-240;l.style.left=`${w}px`,l.style.top=`${T}px`,l.style.bottom=`auto`;let E=e=>{e.target.closest(`.btn-finish`)||(y=!0,S=e.clientX-w,C=e.clientY-T,l.setPointerCapture(e.pointerId))},D=e=>{if(!y)return;let t=e.clientX-S,n=e.clientY-C,r=l.getBoundingClientRect(),i=window.innerWidth-r.width-10,a=window.innerHeight-r.height-10;w=Math.max(10,Math.min(t,i)),T=Math.max(10,Math.min(n,a)),l.style.left=`${w}px`,l.style.top=`${T}px`},O=e=>{if(y){y=!1;try{l.releasePointerCapture(e.pointerId)}catch{}}};l.addEventListener(`pointerdown`,E),l.addEventListener(`pointermove`,D),l.addEventListener(`pointerup`,O),l.addEventListener(`pointercancel`,O),i.appendChild(l),document.body.appendChild(n),u=Date.now(),a=window.setInterval(()=>{let e=Math.floor((Date.now()-u)/1e3);h.textContent=c(e)},1e3)}async function w(n,r){try{let i=await o();t=[],f=!1;let a;if(n===`camera`)p=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:1920},height:{ideal:1080},facingMode:`user`},audio:r?{echoCancellation:!0,noiseSuppression:!0}:!1}),a=p,C(p,n,i);else{if(n===`screen-camera`)try{p=await navigator.mediaDevices.getUserMedia({video:{width:{ideal:640},height:{ideal:640},facingMode:`user`},audio:!1})}catch(e){console.warn(`[RecordFlow] Camera access failed for bubble:`,e),p=null}if(C(p,n,i),m=await navigator.mediaDevices.getDisplayMedia({video:{displaySurface:`monitor`},audio:!0}),m.getVideoTracks()[0].onended=()=>{x(n)},r)try{h=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:!0,noiseSuppression:!0}}),_=new AudioContext;let e=_.createMediaStreamDestination(),t=m.getAudioTracks();t.length>0&&_.createMediaStreamSource(new MediaStream(t)).connect(e),_.createMediaStreamSource(h).connect(e),a=new MediaStream([...m.getVideoTracks(),...e.stream.getAudioTracks()])}catch(e){console.warn(`[RecordFlow] Mic mixing failed, falling back to screen audio:`,e),a=m}else a=m}g=a;let s=v();return e=new MediaRecorder(a,{mimeType:s,videoBitsPerSecond:3e6}),e.ondataavailable=e=>{e.data&&e.data.size>0&&t.push(e.data)},e.onstop=()=>{S(n)},e.start(1e3),{success:!0}}catch(e){return console.error(`[RecordFlow] Recording error:`,e),y(),b(),chrome.runtime.sendMessage({type:`RECORDING_CANCELLED`}),{success:!1,error:e?.message||`USER_CANCELLED`}}}chrome.runtime.onMessage.addListener((e,t,n)=>{if(e.type===`START_RECORDING_INTERNAL`)return w(e.mode||`screen-camera`,e.mic!==!1).then(e=>n(e)).catch(e=>n({success:!1,error:e.message})),!0;if(e.type===`STOP_RECORDING_INTERNAL`)return x(e.mode||`screen-camera`),n({success:!0}),!0})}}),d={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},f=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,p=class e extends Event{static EVENT_NAME=m(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function m(e){return`${f?.runtime?.id}:content:${e}`}var h=typeof globalThis.navigation?.addEventListener==`function`;function g(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),h?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new p(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new p(e,t)),t=e)},1e3))}}}var _=class e{static SCRIPT_STARTED_MESSAGE_TYPE=m(`wxt:content-script-started`);id;abortController;locationWatcher=g(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return f.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?m(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),d.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{e instanceof CustomEvent&&this.verifyScriptStartedEvent(e)&&this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},v={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=u;return await e(new _(`content`,t))}catch(e){throw v.error(`The content script "content" crashed on startup!`,e),e}})()})();
content;